clear
python3 phone-inf.py -n +916235369260

